package com.dicoding.malanginsider.ui.detail

import androidx.fragment.app.Fragment
import com.dicoding.malanginsider.R

private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [PenginapanDeskripsi.newInstance] factory method to
 * create an instance of this fragment.
 */
class PenginapanDeskripsi : Fragment(R.layout.penginapan_deskripsi) {
}