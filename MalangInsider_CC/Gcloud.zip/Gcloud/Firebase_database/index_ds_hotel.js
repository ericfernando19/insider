const admin = require("firebase-admin");
const csv = require("csv-parser");
const fs = require("fs");

// Inisialisasi Firebase
const serviceAccount = require("./malang-insider-firebase-adminsdk-qkn5r-0f70348d9a.json"); // Path ke file kunci layanan Firebase
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

const db = admin.firestore();

// Baca CSV dan unggah ke Firestore
fs.createReadStream("dataset_hotel.csv") // Path ke file CSV
  .pipe(csv())
  .on("dataset_hotel", async (row) => {
    try {
      const docId = row.placeId; // Menggunakan kolom 'placeId' sebagai document ID
      delete row.placeId; // Hapus placeId dari data agar tidak duplikat di Firestore
      const location = {
        lat: parseFloat(row["location/lat"]),
        lng: parseFloat(row["location/lng"]),
      };
      delete row["location/lat"];
      delete row["location/lng"];
      await db.collection("dataset_hotel").doc(docId).set({
        ...row,
        location, // Tambahkan lokasi dalam format lat/lng sebagai objek
      });
      console.log(`Data dengan placeId ${docId} berhasil diunggah.`);
    } catch (error) {
      console.error("Error mengunggah data:", error);
    }
  })
  .on("end", () => {
    console.log("Semua data berhasil diproses.");
  });
