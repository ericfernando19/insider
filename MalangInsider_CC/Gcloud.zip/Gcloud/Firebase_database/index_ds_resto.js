const admin = require("firebase-admin");
const csv = require("csv-parser");
const fs = require("fs");

// Inisialisasi Firebase
const serviceAccount = require("./malang-insider-firebase-adminsdk-qkn5r-0f70348d9a.json"); // Path ke file kunci layanan Firebase
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

const db = admin.firestore();

// Baca CSV dan unggah ke Firestore
fs.createReadStream("dataset_resto.csv") // Path ke file CSV
  .pipe(csv())
  .on("data", async (row) => {
    try {
      const docId = row.placeId; // Menggunakan kolom 'placeId' sebagai document ID
      if (!docId) {
        console.warn("Peringatan: placeId kosong. Baris dilewati:", row);
        return; // Lewati jika placeId kosong
      }

      // Menyusun data sesuai dengan struktur yang diinginkan
      const location = {
        lat: parseFloat(row["location/lat"]),
        lng: parseFloat(row["location/lng"]),
      };
      delete row["location/lat"];
      delete row["location/lng"];

      const openingHours = [
        { day: row["openingHours/0/day"], hours: row["openingHours/0/hours"] },
        { day: row["openingHours/1/day"], hours: row["openingHours/1/hours"] },
        { day: row["openingHours/2/day"], hours: row["openingHours/2/hours"] },
        { day: row["openingHours/3/day"], hours: row["openingHours/3/hours"] },
        { day: row["openingHours/4/day"], hours: row["openingHours/4/hours"] },
        { day: row["openingHours/5/day"], hours: row["openingHours/5/hours"] },
        { day: row["openingHours/6/day"], hours: row["openingHours/6/hours"] },
      ];

      const data = {
        name: row.name,
        rating: parseFloat(row.rating) || 0.0,
        review: row.review,
        category: row.category,
        city: row.city,
        address: row.address,
        postalCode: row.postalCode,
        imageUrl: row.imageUrl,
        url: row.url,
        phone: row.phone,
        location,
        openingHours,
      };

      // Unggah data ke Firestore
      await db.collection("dataset_resto").doc(docId).set(data);
      console.log(`Data dengan placeId ${docId} berhasil diunggah.`);
    } catch (error) {
      console.error("Error mengunggah data:", error);
    }
  })
  .on("end", () => {
    console.log("Semua data berhasil diproses.");
  });
