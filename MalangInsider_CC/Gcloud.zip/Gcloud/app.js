const http = require('http');

// Create the server
const server = http.createServer((req, res) => {
  // Set the response header
  res.setHeader('Content-Type', 'text/html');

  // Handle different routes
  if (req.url === '/') {
    res.statusCode = 200;
    res.end('<h1>Hello, World!</h1>');
  } else if (req.url === '/about') {
    res.statusCode = 200;
    res.end('<h1>About Us</h1><p>This is a simple Node.js app.</p>');
  } else {
    res.statusCode = 404;
    res.end('<h1>Page Not Found</h1>');
  }
});

// Set the server to listen on port 8080 or any other available port
const port = process.env.PORT || 8080;
server.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
